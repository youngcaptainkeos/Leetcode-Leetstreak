export const API_BASE = "https://codestreak-api.onrender.com/api";

export interface RegisterResponse {
  id: number;
  name: string;
  leetcode_username: string;
  avatar_url?: string;
  access_token?: string;
  token_type?: string;
  created_at?: string;
  global_leaderboard_enabled?: boolean;
}

export interface DayCount {
  date: string;
  problems_solved: number;
}

export interface PointBreakdown {
  difficulty?: string;
  raw_base_points?: number;
  ac_rate?: number;
  ac_multiplier?: number;
  ac_adjustment?: number;
  base_points: number;
  contest_rating?: number;
  is_daily: boolean;
  daily_bonus: number;
  subtotal?: number;
  streak_days: number;
  streak_multiplier: number;
  points_earned: number;
}

export interface RecentSolve {
  title_slug: string;
  title: string;
  solved_at: string;
  relative_time: string;
  leetcode_url: string;
  points_earned?: number;
  breakdown?: PointBreakdown;
}

export interface DashboardResponse {
  id: number;
  name: string;
  leetcode_username: string;
  avatar_url?: string;
  easy_count: number;
  medium_count: number;
  hard_count: number;
  current_streak: number;
  today_count: number;
  weekly_total: number;
  monthly_total: number;
  created_at?: string;
  last_7_days: DayCount[];
  global_leaderboard_enabled?: boolean;
}

export interface LeaderboardEntry {
  rank: number;
  id: number;
  name: string;
  leetcode_username: string;
  avatar_url?: string;
  easy_count: number;
  medium_count: number;
  hard_count: number;
  points: number;
  weekly_total: number;
  current_streak: number;
  consistency_score: number;
  combined_score: number;
  is_active_today: boolean;
  kudos_count?: number;
  has_kudosed?: boolean;
}

export interface VersionCheckResponse {
  latest_version: string;
  min_supported_version: string;
  release_notes: string;
  download_url: string;
  crx_url: string;
}

export async function checkExtensionVersion(): Promise<VersionCheckResponse | null> {
  try {
    const res = await fetch(`${API_BASE}/extension/version`);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

export interface DynamicMenuItem {
  id: string;
  label: string;
  icon: string;
  type: "tab" | "link" | "modal";
  url?: string;
  enabled: boolean;
}

export interface AppConfigResponse {
  version: string;
  maintenance_mode: boolean;
  announcement?: string;
  menu_items: DynamicMenuItem[];
  whatsapp_share_url?: string;
}

export async function getAppConfig(): Promise<AppConfigResponse | null> {
  try {
    const res = await fetch(`${API_BASE}/config/app`);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

export interface LeaderboardResponse {
  week_start: string;
  week_end: string;
  total_users?: number;
  entries: LeaderboardEntry[];
}

export interface GroupMember {
  id: number;
  name: string;
  leetcode_username: string;
  avatar_url?: string;
}

export interface GroupResponse {
  id: number;
  name: string;
  code: string;
  creator_id?: number;
  member_count: number;
  members: GroupMember[];
}

export interface GroupListResponse {
  groups: GroupResponse[];
}

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `Request failed (${res.status})`);
  }
  return res.json();
}

export const api = {
  register: (name: string, leetcode_username: string, email: string, password: string, global_leaderboard_enabled: boolean = true) =>
    request<RegisterResponse>("/users/register", {
      method: "POST",
      body: JSON.stringify({ name, leetcode_username, email, password, global_leaderboard_enabled }),
    }),
  login: (leetcode_username: string, password: string) =>
    request<RegisterResponse>("/users/login", {
      method: "POST",
      body: JSON.stringify({ leetcode_username, password }),
    }),
  initiateForgotPassword: (email_or_username: string) =>
    request<{ status: string; email: string }>("/users/forgot-password/initiate", {
      method: "POST",
      body: JSON.stringify({ email_or_username }),
    }),
  verifyForgotPassword: (email_or_username: string, otp: string, new_password: string) =>
    request<{ status: string }>("/users/forgot-password/verify", {
      method: "POST",
      body: JSON.stringify({ email_or_username, otp, new_password }),
    }),
  dashboard: (userId: number) =>
    request<DashboardResponse>(`/users/${userId}/dashboard`),
  syncUser: (userId: number) =>
    request<{ status: string; new_solves: number }>(`/users/${userId}/sync`, { method: "POST" }),
  updateLeetcodeUsername: (userId: number, leetcode_username: string) =>
    request<{ status: string; user_id: number; leetcode_username: string; avatar_url?: string }>(
      `/users/${userId}/leetcode-username`,
      {
        method: "PUT",
        body: JSON.stringify({ leetcode_username }),
      }
    ),
  updateSettings: (userId: number, settings: { global_leaderboard_enabled: boolean }) =>
    request<{ status: string; user_id: number; global_leaderboard_enabled: boolean }>(
      `/users/${userId}/settings`,
      {
        method: "PUT",
        body: JSON.stringify(settings),
      }
    ),
  deleteAccount: (userId: number, password: string) =>
    request<{ status: string; message: string }>(`/users/${userId}/delete-account`, {
      method: "POST",
      body: JSON.stringify({ password }),
    }),
  leaderboard: (userId?: number, sortBy: "points" | "streak" = "points") => {
    const params = new URLSearchParams();
    if (userId) params.set("user_id", String(userId));
    if (sortBy) params.set("sort_by", sortBy);
    return request<LeaderboardResponse>(`/leaderboard?${params.toString()}`);
  },
  friendsLeaderboard: (userId: number, sortBy: "points" | "streak" = "points") => {
    const params = new URLSearchParams();
    params.set("user_id", String(userId));
    if (sortBy) params.set("sort_by", sortBy);
    return request<LeaderboardResponse>(`/friends/leaderboard?${params.toString()}`);
  },
  createGroup: (userId: number, name: string) =>
    request<GroupResponse>("/groups", {
      method: "POST",
      body: JSON.stringify({ user_id: userId, name }),
    }),
  joinGroup: (userId: number, code: string) =>
    request<GroupResponse>("/groups/join", {
      method: "POST",
      body: JSON.stringify({ user_id: userId, code }),
    }),
  removeMember: (groupId: number, memberUserId: number, requesterUserId: number) =>
    request<{ status: string }>(
      `/groups/${groupId}/members/${memberUserId}?requester_id=${requesterUserId}`,
      { method: "DELETE" }
    ),
  deleteGroup: (groupId: number, requesterUserId: number) =>
    request<{ status: string; group_id: number }>(
      `/groups/${groupId}?requester_id=${requesterUserId}`,
      { method: "DELETE" }
    ),
  myGroups: (userId: number) =>
    request<GroupListResponse>(`/groups/my-groups/${userId}`),
  groupLeaderboard: (groupId: number, userId?: number, sortBy: "points" | "streak" = "points") => {
    const params = new URLSearchParams();
    if (userId) params.set("user_id", String(userId));
    if (sortBy) params.set("sort_by", sortBy);
    return request<LeaderboardResponse>(`/groups/${groupId}/leaderboard?${params.toString()}`);
  },
  toggleKudos: (toUserId: number, fromUserId: number) =>
    request<{ status: string; to_user_id: number; kudos_count: number; has_kudosed: boolean }>(
      `/kudos/${toUserId}`,
      {
        method: "POST",
        body: JSON.stringify({ from_user_id: fromUserId }),
      }
    ),
  kudosAll: (fromUserId: number, targetUserIds: number[]) =>
    request<{ status: string; updated_count: number }>("/kudos/kudos-all", {
      method: "POST",
      body: JSON.stringify({ from_user_id: fromUserId, target_user_ids: targetUserIds }),
    }),
  recentSolves: (userId: number, limit = 10) =>
    request<RecentSolve[]>(`/users/${userId}/recent-solves?limit=${limit}`),
  pollNow: () => request<{ polled: Record<string, number> }>("/admin/poll-now", { method: "POST" }),
  checkExtensionVersion: checkExtensionVersion,
  getAppConfig: getAppConfig,
};

